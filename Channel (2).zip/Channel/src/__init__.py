"""
Channel Manager - Source Package
"""
