# 🏨 Channel Manager

Sistema de gestión de hoteles, habitaciones, disponibilidad y reservas.

**Lanzamiento rápido**: 
```bash
npm run dev
```

> ✅ Backend + Frontend se lanzan automáticamente en una sola terminal

---

## 📚 Documentación

- **[QUICK_START.md](QUICK_START.md)** ← **Empieza aquí** ⭐
- **[INICIALIZACION.md](INICIALIZACION.md)** - Manual completo de instalación
- **[API_DOCUMENTATION.md](API_DOCUMENTATION.md)** - Todos los endpoints
- **[MODELO_CONCEPTUAL.md](MODELO_CONCEPTUAL.md)** - Diagrama de base de datos
- **[JWT_OPTIMIZATION.md](JWT_OPTIMIZATION.md)** - Optimizaciones de autenticación

---

## 🚀 Inicio Rápido

### Requisitos
- Node.js ≥ 16.0.0
- Python ≥ 3.9.0

### 1. Primera vez (instalación)
```bash
npm run install-all
```

### 2. Ejecutar todo
```bash
npm run dev
```

### 3. Abrir en navegador
- Frontend: http://localhost:5173
- API Docs: http://127.0.0.1:8001/docs
- Login: `nasim@gmail.com` / `Malika2004`

---

## 🛠️ Stack Tecnológico

**Backend**:
- FastAPI - Framework web moderno
- SQLAlchemy - ORM
- JWT + bcrypt - Autenticación segura
- SQLite - Base de datos

**Frontend**:
- Vue 3 - Framework reactivo
- Vite - Build tool rápido
- Vue Router - Enrutamiento
- Axios - Cliente HTTP

---

## 📂 Estructura del Proyecto

```
Channel/
├── package.json              ← npm scripts
├── requirements.txt          ← dependencias Python
├── src/                      ← Backend FastAPI
│   ├── main.py
│   ├── models/
│   ├── routes/
│   └── schemas/
├── frontend/                 ← Frontend Vue 3
│   ├── src/
│   ├── package.json
│   └── vite.config.js
├── channel.db               ← Base de datos
└── documentación/
    ├── QUICK_START.md
    ├── INICIALIZACION.md
    ├── API_DOCUMENTATION.md
    ├── MODELO_CONCEPTUAL.md
    └── JWT_OPTIMIZATION.md
```

---

## 📖 Tecnologías

- **FastAPI** - Framework web moderno y rápido
- **SQLAlchemy** - ORM para base de datos
- **SQLite** - Base de datos
- **Pydantic** - Validación de datos

## Instalación

```bash
# Crear entorno virtual (opcional)
python -m venv venv
venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt
```

## Ejecución

```bash
# Desde el directorio Channel
python -m uvicorn src.main:app --reload --port 8001
```

## Endpoints

- `GET /` - Estado del servidor
- `GET /health` - Health check
- `GET /api/hoteles` - Listar hoteles
- `GET /api/disponibilidad` - Consultar disponibilidad
- `POST /api/reservas` - Crear reserva
- `GET /api/reservas` - Listar reservas

## Estructura

```
Channel/
├── requirements.txt
├── README.md
└── src/
    ├── main.py          # Punto de entrada FastAPI
    ├── config.py        # Configuración
    ├── database.py      # Conexión BD
    ├── models/          # Modelos SQLAlchemy
    ├── schemas/         # Schemas Pydantic
    └── routes/          # Endpoints API
```
